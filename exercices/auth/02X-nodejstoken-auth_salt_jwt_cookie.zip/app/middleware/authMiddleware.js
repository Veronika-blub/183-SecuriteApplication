const jwt = require('jsonwebtoken');

const isAuthenticated = (req, res, next) => {
    
    console.log(req.cookies);
    const token = req.cookies.authToken; // Lecture du token JWT dans le cookie

    if (!token) {
        console.log("Pas de token trouvé.");
        return res.redirect('/auth/login'); 
    }

    try {
        const secretKey = 'hajskdhsajkd2332932';
        const decoded = jwt.verify(token, secretKey);
        req.user = decoded.username; 
        console.log("Token valide :", decoded.username);
        next();
    } catch (error) {
        console.error("Token invalide :", error);
        res.clearCookie('authToken'); 
        return res.redirect('/auth/login');
    }
}

module.exports = { isAuthenticated };

