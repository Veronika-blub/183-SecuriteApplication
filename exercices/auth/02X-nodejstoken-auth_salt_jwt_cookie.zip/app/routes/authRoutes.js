const express = require('express');

const router = express.Router();
const controller = require("../controllers/AuthController");

router.get('/login', controller.get);
router.post('/login', controller.authenticateUser);
router.get('/register', controller.showRegisterPage);
router.post('/register', controller.registerUser);


module.exports = router; 