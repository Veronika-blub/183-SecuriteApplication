const mysql = require('mysql2');


const pool = mysql.createPool({
    host: 'db_container',
    user: 'root',
    password: 'root',
    database: 'db_authentication',
    port: 3306
});


module.exports = pool.promise();
