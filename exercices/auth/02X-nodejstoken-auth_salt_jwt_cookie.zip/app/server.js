

const express = require("express");
const app = express();
const cookieParser = require('cookie-parser');
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser()); 
// Nouvelle ligne : on défini notre moteur de vue
app.set("view engine", "ejs");

// ... par défaut EJS a besoin d'un dossier "views"
// Si on veut un autre dossier, on peut faire :
//app.set('views', path.join(__dirname, '/yourViewDirectory')); 
const userRoutes = require('./routes/userRoutes');
const authRoutes = require('./routes/authRoutes');
const homeRoutes = require('./routes/homeRoutes');

// On commence par mettre les routes publiques permettant à l'utilisateur de se connecter
app.use('/auth', authRoutes);


// A partir de ce point toutes les routes sont par défaut protégées.
const { isAuthenticated } = require('./middleware/authMiddleware'); 
app.use(isAuthenticated);
app.use('/user', userRoutes);
app.use('/', homeRoutes);

// Démarrage du serveur
app.listen(8080, () => {
    console.log('Server running on port 8080');
});



// todo : soignez l'écriture dans la db
// todo : émettre un token
// todo : vérifier un token
// todo : protéger les routes
// todo : mise en place d'un middleware d'authentification
//        