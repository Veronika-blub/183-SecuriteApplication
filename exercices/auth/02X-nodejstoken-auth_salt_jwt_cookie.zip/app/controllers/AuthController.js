const jwt = require('jsonwebtoken');

module.exports = {
    get: (req, res) => {
        res.render("login");
    },
    
    showRegisterPage: (req, res) => {
        res.render("register");
    },
    
    authenticateUser: async (req, res) => {
        console.log(req.body);
        const db = require('../db');
        const [results, fields] = await db.execute('SELECT useSalt, usePassword FROM t_users WHERE idUser = ?', [req.body.username]);
        console.log(results);
        
        if (!results || results.length === 0){
            res.status(401).json("Utilisateur ou mot de passe incorrect");
            return;
        }
        
        // get hash and salt from db
        const salt = results[0].useSalt;
        const hash = results[0].usePassword;      
        
        
        // concatanate the received password with the salt
        const passwordPlusSalt = salt + req.body.password;
        
        // ... hash it
        const computedHash = hashData(passwordPlusSalt);
        
        // ... compare it to the stored hash        
        if (computedHash === hash){        
            console.log("User authenticated");
            console.log("User authenticated");

            const secretKey = 'hajskdhsajkd2332932';

            const payload = {
                username: req.body.username, 
                role: "user" 
            };

            const options = {
                expiresIn: '1h' 
            };

            const token = jwt.sign(payload, secretKey, options);

            res.cookie('authToken', token, {
                httpOnly: true,
                secure: false, 
                maxAge: 3600000
            });

            return res.redirect("/");
            
        }
        else {
            
            return res.redirect("/auth/login");
        }
        return res.redirect("/");
    },
    
    registerUser:  async (req, res) => {
        const db = require('../db');
        
        // generate a new salt
        const salt = generateSalt();
        
        // concatenate the salt with the Password
        const passwordPlusSalt = salt + req.body.password;
        
        // ... hash it        
        const hash = hashData(passwordPlusSalt);
        
        // save the new user to the database
        const [results, fields] = await db.execute('INSERT INTO t_users (idUser, useSalt, usePassword) VALUES (?, ?, ?)', [req.body.username, salt, hash]);
        
        
        console.log("User created");
        return res.redirect("/");
    }
};

function generateSalt(){

    let salt = '';
    for (let i = 0; i < 16; i++){
        salt += generateRandomChar();  
    }
    return salt;

}

function generateRandomChar() {
    const randomCharCode = Math.floor(Math.random() * (126 - 32 + 1)) + 32; 
    return String.fromCharCode(randomCharCode);
}

function hashData(data) {
    const {createHash} = require('node:crypto'); 
    const hash = createHash('sha256');      
    hash.update(data);
    return hash.digest('hex'); 
}
    

