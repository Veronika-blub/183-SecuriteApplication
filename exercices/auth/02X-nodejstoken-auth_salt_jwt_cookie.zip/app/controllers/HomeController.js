z

module.exports = {
    get: (req, res) => {
        res.render("landing", {"pageTitle":"Bienvenue !" , "userName": req.user || "invité" });
    },
};


