

module.exports = {
    get: (req, res) => {
        res.send("User: Sarah");
    },
    
    getUsers: async (req, res) => {
        try {
            const [rows] = await db.query('SELECT * FROM t_users');
            res.status(200).json(rows);
        } catch (error) {
            console.error('Erreur lors de la récupération des utilisateurs :', error);
            res.status(500).json({ message: 'Erreur interne' });
        }
    }
};

